!!English Version below!!
Bug Report: Discord -> ben942
#Einbau Anleitung CCI1200

Voraussetzungen:
Giants Editor 10.0.X
Text Editor z.B. Notepad++

--------------------------
Um mit dem Einbau zu starten sollten die folgenden Dateien in den entpackten Ordner ihres Mods verschoben werden:
cci1200.i3d
cci1200.i3d.shapes
textures

Falls bereits ein textures Ordner existiert, sollten die enthaltenen Dateien automatisch in den vorhandenen Ordner verschoben werden.
--------------------------
Öffnen sie nun ihre Mod.i3d -> Klicken sie den Button "Import i3D File" -> Öffnen sie die cci1200.i3d, die sie zuvor in ihren Modordner verschoben haben
-> Verschieben sie das "cciStandPart" in eine geeignete Transform Gruppe z.B. die "configurations" der Kabine -> Sie können die verschiedenen "cciStandParts" beliebig bewegen,
um das Display auszurichten -> Sind sie mit der Positionierung zufrieden speichern sie die i3d ab und folgen sie den folgenden XML schritten.
--------------------------
Öffnen sie ihre Mod.xml mit einem Text Editors ihres beliebens, in meinem Fall Notepad++ -> Scrollen sie bis an das Ende der Datei und fügen sie weitere i3dMappings hinzu:
	<i3dMapping id="cciStandPart" node="XXX" />
        <i3dMapping id="cciNumbersTime" node="XXX" />
        <i3dMapping id="cciNumbersWorkingTime" node="XXX" />
        <i3dMapping id="cciNumbersSpeed" node="XXX" />
        <i3dMapping id="cciDisplay" node="XXX" />

-> die Nodes sind hier mit "XXX" angegeben, bitte passen sie diese selbstständig an. Die Node kann in der i3d ausgelesen werden, indem sie das genannte Objekt anklicken und im
Attributes Fenster den Index Path kopieren. Die XXX müssen durch diesen "Index Path" ersetzt werden.

-> Benutzen sie anschließend die Suchfunktion (Strg+F) und suchen sie folgenden Begriff: "Dashboard" (Ohne "") die Gruppe sollte wiefolgt aussehen: (Nicht 1:1)

   <dashboard>
        <groups>
            <group name="MOTOR_STARTING" isMotorStarting="true"/>
            <group name="MOTOR_ACTIVE"   isMotorStarting="true" isMotorRunning="true"/>
            <group name="MOTOR_RUNNING"  isMotorRunning="true"/>
            <group name="BACK_ATTACHMENT"  attacherJointIndices="1 3 4"/>
            <group name="FRONT_ATTACHMENT" attacherJointIndices="2 5"/>
        </groups>

        <default>
            <dashboard displayType="EMITTER" .../>
            <dashboard displayType="EMITTER" .../>
            <dashboard displayType="EMITTER" .../>
        </default>
    </dashboard>

-> Fügen sie ein weiteres Dashboard hinzu: <dashboard displayType="EMITTER" node="cciDisplay" idleValue="-1" intensity="0.2" groups="MOTOR_ACTIVE"/>
-> Suchen sie anschließend weiter bis sie zur Dashboard Gruppe in der motorized Gruppe gelangen
-> Fügen sie dort folgenden Eintrag hinzu: <dashboard displayType="TEXT" valueType="speed" node="cciNumbersSpeed" textColor="0 0 0 1" precision="1" textMask="00.0" textSize="0.2" textAlignment="CENTER" font="GENERIC" groups="MOTOR_ACTIVE"/>
-> Suchen sie zuletzt die Dashboard Gruppe in der enterable Gruppe und fügen sie dort folgende Zeile hinzu:
 
	<dashboard displayType="TEXT" valueType="operatingTime" node="cciNumbersWorkingTime" textColor="1 1 1 1" textMask="00:00" textSize="0.1" precision="1" textAlignment="CENTER" font="GENERIC" groups="MOTOR_ACTIVE"/>
	<dashboard displayType="TEXT" valueType="time"          node="cciNumbersTime"          textColor="1 1 1 1" textMask="00:00"   textSize="0.1" textAlignment="CENTER" precision="2" font="GENERIC" groups="MOTOR_ACTIVE"/>

-> Speichern sie die Mod.xml und die Mod.i3d und löschen sie folgende Dateien aus ihrem Modordner: cci1200.i3d, cci1200.i3d.shapes -> WICHTIG!! Der "textures" Ordner muss bestehen bleiben.
-> Starten sie anschließend ihr Spiel und Testen sie ob alles Ordnungsgemäß funktioniert


-------------------------------------------------------------------------------------------------------------------------------


#Installation instructions CCI1200

Requirements:
Giants Editor 10.0.X
Text editor e.g. Notepad++

--------------------------
To start the installation, the following files should be moved to the unzipped folder of your mod:
cci1200.i3d
cci1200.i3d.shapes
textures

If a textures folder already exists, the contained files should be automatically moved to the existing folder.
--------------------------
Now open your Mod.i3d -> Click the "Import i3D File" button -> Open the cci1200.i3d that you previously moved to your mod folder
-> Move the "cciStandPart" to a suitable Transform group, e.g. the "configurations" of the cabin -> You can move the various "cciStandParts" as you wish,
to align the display -> If you are satisfied with the positioning, save the i3d and follow the XML steps below.
--------------------------
Open your Mod. xml with a text editor of your choice, in my case Notepad++ -> Scroll to the end of the file and add more i3dMappings:
	<i3dMapping id="cciStandPart" node="XXX" />
 <i3dMapping id="cciNumbersTime" node="XXX" />
 <i3dMapping id="cciNumbersWorkingTime" node="XXX" />
 <i3dMapping id="cciNumbersSpeed" node="XXX" />
 <i3dMapping id="cciDisplay" node="XXX" />

-> the nodes are indicated here with "XXX", please adjust them yourself. The node can be read out in the i3d by clicking on the named object and copying the Index Path in the
Attributes window. The XXX must be replaced by this "Index Path".

-> Then use the search function (Ctrl+F) and search for the following term: "Dashboard" (without "") the group should look like this: (Not 1:1)

   <dashboard>
 <groups>
 <group name="MOTOR_STARTING" isMotorStarting="true"/>
 <group name="MOTOR_ACTIVE" isMotorStarting="true" isMotorRunning="true"/>
 <group name="MOTOR_RUNNING" isMotorRunning="true"/>
 <group name="BACK_ATTACHMENT" attacherJointIndices="1 3 4"/>
 <group name="FRONT_ATTACHMENT" attacherJointIndices="2 5"/>
 </groups>

        <default>
 <dashboard displayType="EMITTER" .../>
 <dashboard displayType="EMITTER" .../>
 <dashboard displayType="EMITTER" .../>
 </default>
 </dashboard>

-> Add another dashboard: <dashboard displayType="EMITTER" node="cciDisplay" idleValue="-1" intensity="0.2" groups="MOTOR_ACTIVE"/>
-> Then continue searching until you reach the dashboard group in the motorized group
-> Add the following entry there: <dashboard displayType="TEXT" valueType="speed" node="cciNumbersSpeed" textColor="0 0 0 1" precision="1" textMask="00.0" textSize="0.2" textAlignment="CENTER" font="GENERIC" groups="MOTOR_ACTIVE"/>
-> Finally, search for the dashboard group in the enterable group and add the following line there:
 
	<dashboard displayType="TEXT" valueType="operatingTime" node="cciNumbersWorkingTime" textColor="1 1 1 1" textMask="00:00" textSize="0. 1" precision="1" textAlignment="CENTER" font="GENERIC" groups="MOTOR_ACTIVE"/>
<dashboard displayType="TEXT" valueType="time" node="cciNumbersTime" textColor="1 1 1 1" textMask="00:00" textSize="0.1" textAlignment="CENTER" precision="2" font="GENERIC" groups="MOTOR_ACTIVE"/>

-> Save the Mod.xml and the Mod.i3d and delete the following files from your mod folder: cci1200.i3d, cci1200.i3d.shapes -> IMPORTANT!!! The “textures” folder must remain.
-> Then start your game and test if everything works properly

Translated with DeepL.com (free version)

